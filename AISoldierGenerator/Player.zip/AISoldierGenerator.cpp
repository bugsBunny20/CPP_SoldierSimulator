#include <iostream>
#include "SoldiersFactory.h"
#include "SoldierObject.h"
#include "HandleSoldiers.h"
#include "Player.h"
#include "Grid.h"

using namespace std;

int main()
{
	//int* p = new int(3);
	bool* b = new bool[3];

	//cout << p << endl;
	//cout << *p << endl;

	int* pa = new int[3];

	cout << pa << endl;
	cout << pa + 1 << endl;
	cout << sizeof(pa) << endl;

	cout << b << endl;
	cout << b + 1 << endl;
	cout << sizeof(b) << endl;
	//cout << 
	//cout << *pa << endl;
	//cout << pa[0] << endl;

	return 0;
}
