#include <iostream>
#include "GameManager.h"
#include "Grid.h"
#include "Player.h"

//int numberOfPlayers = 2;
//char isExit = 'N';
//bool firstPlayerTurn = true;
//
//int GameManager::x1 = 0;
//x2 = 0;
//y1 = 0;
//y2 = 0;
//
//int distance = 0;

void GameManager::createGrid()
{
	grid = new Grid(1000, 1000);
}

void GameManager::createPlayers()
{
	players = new Player[numberOfPlayers];
}

void GameManager::createArmy()
{
	for (int i = 0; i < numberOfPlayers; i++)
	{
		std::cout << "\n***** Creating army for player: " << i + 1 << " *****" << std::endl;
		Player player;
		players[i] = player;
		HandleSoldiers handleSoldiers = HandleSoldiers();
		players[i].getArmy(handleSoldiers.createSoldiers());
	}

	for (int i = 0; i < numberOfPlayers; i++)
	{
		std::cout << "\n***** Setting army on grid for player: " << i + 1 << " *****" << std::endl;
		players[i].setArmy(grid);
	}
}

void GameManager::startAttack()
{
	do
	{
		if (firstPlayerTurn)
		{
			for (int i = 0; i < players[0].armyCount; i++) {
				for (int j = 0; j < players[1].armyCount; j++)
				{
					if (!players[0].army[i]->GetIsDead())
					{
						x1 = players[0].army[i]->GetPosX();
						y1 = players[0].army[i]->GetPosX();;

						x2 = players[1].army[j]->GetPosX();
						y2 = players[1].army[j]->GetPosX();;

						distance = sqrt(pow((x2 - x1), 2) + pow((y2 - y1), 2));
						if (players[0].army[i]->GetAttackRange() >= distance) {
							players[1].army[j]->TakeDamage(players[0].army[i]->Attack());
						}
					}

				}
			}
			firstPlayerTurn = false;
		}
		else
		{
			for (int i = 0; i < players[1].armyCount; i++) {
				for (int j = 0; j < players[0].armyCount; j++)
				{
					if (!players[1].army[i]->GetIsDead())
					{
						x1 = players[1].army[i]->GetPosX();
						y1 = players[1].army[i]->GetPosY();

						x2 = players[0].army[j]->GetPosX();
						y2 = players[0].army[j]->GetPosY();
						distance = sqrt(pow((x2 - x1), 2) + pow((y2 - y1), 2));
						if (players[1].army[i]->GetAttackRange() >= distance) {
							players[0].army[j]->TakeDamage(players[1].army[i]->Attack());
						}
					}

				}
			}
			firstPlayerTurn = true;
		}

		std::cout << "Do you want to end the game ? Y/N : " << std::endl;
		std::cin >> isExit;
	} while (isExit != 'Y' && isExit != 'y');
}

void GameManager::deleteArmy()
{
	for (int i = 0; i < numberOfPlayers; i++)
	{
		std::cout << "\n***** Destroying army for player: " << i + 1 << " *****" << std::endl;
		players[i].destroyArmy();
	}
}

GameManager::~GameManager()
{
	delete grid;
	delete[] players;
}
