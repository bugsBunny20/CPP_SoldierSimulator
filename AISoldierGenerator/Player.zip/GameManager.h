#pragma once
#include "Grid.h"
#include "Player.h"
#include "SoldierObject.h"

class GameManager {
private:
	Player* players;
	Grid* grid;
	int numberOfPlayers;
	char isExit;
	bool firstPlayerTurn;

	int x1 = 0;
	int x2 = 0;
	int y1 = 0;
	int y2 = 0;

	float distance = 0.0f;

public:
	void createGrid();
	void createPlayers();
	void createArmy();
	void startAttack();
	void deleteArmy();
	~GameManager();
};
