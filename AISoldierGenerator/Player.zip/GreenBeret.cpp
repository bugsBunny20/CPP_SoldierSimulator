#include <iostream>
#include "GreenBeret.h"
GreenBeret::GreenBeret() {
    Health = 100.0f;
    attackRange = 30;
    moveSpeed = 5;
    damage = 80;
}

GreenBeret:: ~GreenBeret()
{

}