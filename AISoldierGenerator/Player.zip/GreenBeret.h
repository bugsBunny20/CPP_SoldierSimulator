#pragma once
#include "SoldierObject.h"
class GreenBeret : public Soldier {
public:	GreenBeret();
	  ~GreenBeret();
};