#include <iostream>
#include "SoldiersFactory.h"
#include "GreenBeretFactory.h"
#include "GreenBeret.h"

Soldier* GreenBeretFactory::createSoldier()
{
    std::cout << "Creating Green Beret Object" << std::endl;
    return new GreenBeret();
}
GreenBeretFactory :: ~GreenBeretFactory()
{
    std::cout << "Deleteing Green Beret Factory" << std::endl;
}