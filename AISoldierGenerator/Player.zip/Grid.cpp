#include <string>
#include "Grid.h"
#include "SoldierObject.h"

Grid::Grid(int x, int y)
{
	sizeX = x;
	sizeY = y;
	grid = new std::string* [x];
	for (int i = 0; i < x; i++)
	{
		grid[i] = new std::string[y];
	}
	for (int i = 0; i < x; i++)
	{
		for (int j = 0; j < y; j++)
		{
			grid[i][j] = "_";
		}
	}
}

bool Grid::SetSoldierOnGrid(int x, int y, Soldier * soldier)
{
	if (grid[x][y] == "_")
	{
		grid[x][y] = "S";
		soldier->SetPosition(x, y);
		return true;
	}
	else 
	{
		return false;
	}
}

Grid::~Grid()
{
	for (int i = 0; i < sizeX; i++)
	{
		delete[] grid[i];
	}

	delete[] grid;
}

int Grid::getSizeX()
{
	return sizeX;
}

int Grid::getSizeY()
{
	return sizeY;
}
