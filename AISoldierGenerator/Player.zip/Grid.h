#pragma once
#include <string>
#include "SoldierObject.h"

class Grid {
private :
	std::string** grid;
	int sizeX, sizeY;
public :
	int getSizeY();
	int getSizeX();
	Grid(int x, int y);
	bool SetSoldierOnGrid(int x, int y, Soldier* soldier);
	~Grid();
};