#include <iostream>
#include <time.h>
#include "SoldiersFactory.h"
#include "SniperFactory.h"
#include "GreenBeretFactory.h"
#include "MarineFactory.h"
#include "SpyFactory.h"
#include "SoldierObject.h"
#include "HandleSoldiers.h"
#include "Grid.h"

HandleSoldiers::HandleSoldiers() {
	armyCount = 20;
	typeOfSoldiersAvailable = 4;
	soldiers = new Soldier * [armyCount];
}

Soldier** HandleSoldiers::createSoldiers()
{
	SoldiersFactory* sniperFactory = new SniperFactory();
	SoldiersFactory* greenBeretFactory = new GreenBeretFactory();
	SoldiersFactory* marineFactory = new MarineFactory();
	SoldiersFactory* spyFactory = new SpyFactory();
	srand(time(0));

	for (int j = 0; j < armyCount; j++)
	{
		int randomSeed = (rand() % typeOfSoldiersAvailable)+1;
		Soldier* soldier = NULL;
		switch (randomSeed)
		{
		case 1 :
			soldier = sniperFactory->createSoldier();
			break;
		case 2:
			soldier = greenBeretFactory->createSoldier();
			break;
		case 3:
			soldier = marineFactory->createSoldier();
			break;
		case 4:
			soldier = spyFactory->createSoldier();
			break;
		}
		if (soldier != NULL) 
		{
			soldiers[j] = soldier;
		}
	}
	return soldiers;
}

void HandleSoldiers::setSoldiers(Grid* grid, Soldier** army, int minY)
{
	srand(time(0));
	bool isSoldierSet;
	
	for (int j = 0; j < armyCount; j++)
	{
		int posX = (rand() % grid->getSizeX()) + 1;
		int posY = (rand() % (grid->getSizeY()-minY)) + minY;
		isSoldierSet = grid->SetSoldierOnGrid(posX, posY,army[j]);
		if (!isSoldierSet) 
		{
			j--;
		}
	}
}

void HandleSoldiers::deleteSoldiers(Soldier** army)
{
	for (int j = 0; j < armyCount; j++)
	{
		delete soldiers[j];
	}
}