#pragma once
#include "SoldierObject.h"
#include "SoldiersFactory.h"
#include "Grid.h"


class HandleSoldiers {

private: Soldier** soldiers;
	   int armyCount;
	   int typeOfSoldiersAvailable;
public:
	HandleSoldiers();
	Soldier** createSoldiers();
	void setSoldiers(Grid* grid, Soldier** army, int minY);
	void deleteSoldiers(Soldier** army);
};