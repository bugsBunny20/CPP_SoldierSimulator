#include <iostream>
#include "Marine.h"
Marine::Marine() {
    Health = 80.0f;
    attackRange = 50;
    moveSpeed = 10;
    damage = 60;
}

Marine:: ~Marine()
{

}