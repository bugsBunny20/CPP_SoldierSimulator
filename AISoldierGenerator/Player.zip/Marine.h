#pragma once
#include "SoldierObject.h"
class Marine : public Soldier {
public:Marine();
	  ~Marine();
};