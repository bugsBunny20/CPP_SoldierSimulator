#include <iostream>
#include "SoldiersFactory.h"
#include "MarineFactory.h"
#include "Marine.h"

Soldier* MarineFactory::createSoldier()
{
    std::cout << "Creating Marine Object" << std::endl;
    return new Marine();
}
MarineFactory :: ~MarineFactory()
{
    std::cout << "Deleteing Marine Factory" << std::endl;
}
