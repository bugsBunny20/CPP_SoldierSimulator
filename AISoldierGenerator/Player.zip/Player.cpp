#include <iostream>
#include "HandleSoldiers.h"
#include "SoldierObject.h"
#include "SoldiersFactory.h"
#include "Player.h"
#include "Grid.h"

Player::Player() {
	armyCount = 20;
	handleSoldiers;
	army = new Soldier * [armyCount];
}

void Player::destroyArmy() {
	handleSoldiers.deleteSoldiers(army);
}

void Player::getArmy(Soldier** soldierArmy)
{
	for (int i = 0; i < armyCount; i++) {
		army[i] = soldierArmy[i];
	}
}

void Player::setArmy(Grid* grid) {
	handleSoldiers.setSoldiers(grid,army,);
}
