#pragma once
#include "HandleSoldiers.h"
#include "SoldierObject.h"
#include "SoldiersFactory.h"
#include "Grid.h"

class Player {
	HandleSoldiers handleSoldiers;

public:
	Player();
	//get array of soldiers
	int armyCount;
	Soldier** army;
	
	void getArmy(Soldier** soldirArmy);
	void setArmy(Grid* grid);
	void destroyArmy();
};