#include <iostream>
#include "Sniper.h"
Sniper::Sniper() {
    Health = 50.0f;
    attackRange = 150;
    moveSpeed = 2;
    damage = 100;
}

Sniper:: ~Sniper()
{

}

