#pragma once
#include "SoldierObject.h"
class Sniper : public Soldier {
public:	Sniper();
	  ~Sniper();
};