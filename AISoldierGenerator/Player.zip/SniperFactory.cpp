#include <iostream>
#include "SoldiersFactory.h"
#include "SniperFactory.h"
#include "Sniper.h"

Soldier* SniperFactory::createSoldier()
{
    std::cout << "Creating Sniper Object" << std::endl;
    return new Sniper();
}
SniperFactory :: ~SniperFactory()
{
    std::cout << "Deleteing Sniper Factory" << std::endl;
}