#include <iostream>
#include "SoldierObject.h"

Soldier :: ~Soldier()
{
    std::cout << "Deleteing soldier object" << std::endl;
}

int Soldier::GetPosX()
{
    return posX;
}

int Soldier::GetPosY()
{
    return posY;
}

bool Soldier::GetIsDead()
{
    return isDead;
}

int Soldier::GetMoveSpeed()
{
    return moveSpeed;
}

float Soldier::GetAttackRange()
{
    return attackRange;
}

int Soldier::Attack()
{
    std::cout << "Soldier gave damage: " << damage << std::endl;
    if (!isDead) {
        return damage;
    }
    else
    {
        return 0;
    }
}

void Soldier::TakeDamage(int damage)
{
    if (!isDead) {
        Health -= damage;
        std::cout << "Soldier took damage: " << damage << std::endl;
    }
    if (Health <= 0) {
        isDead = true;
    }
}

void Soldier::SetPosition(int x, int y)
{
    posX = x;
    posY = y;
    std::cout << "Soldier position: " << posX << "," << posY << std::endl;
}
