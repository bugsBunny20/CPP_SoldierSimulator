#pragma once
class Soldier {
protected:
	float Health = 50.0f;
	int posX = 0;
	int posY = 0;
	float attackRange = 0;
	bool isDead = false;
	int moveSpeed = 1;
	int damage = 50;


public:
	int GetPosX();
	int GetPosY();
	bool GetIsDead();
	int GetMoveSpeed();
	float GetAttackRange();

	int Attack();
	void TakeDamage(int damage);
	void SetPosition(int x, int y);
	virtual ~Soldier();
};