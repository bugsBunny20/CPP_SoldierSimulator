#include <iostream>
#include "SoldiersFactory.h"
#include "SoldierObject.h"

SoldiersFactory :: ~SoldiersFactory()
{
    std::cout << "Deleteing soldier factory" << std::endl;
}

