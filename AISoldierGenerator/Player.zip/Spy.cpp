#include <iostream>
#include "Spy.h"

Spy::Spy() {
    Health = 60.0f;
    attackRange = 20;
	moveSpeed = 1;
	damage = 70;
}
Spy:: ~Spy()
{

}