#pragma once
#include "SoldierObject.h"
class Spy : public Soldier {
public:	Spy();
	  ~Spy();
};