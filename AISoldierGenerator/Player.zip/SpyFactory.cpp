#include <iostream>
#include "SoldiersFactory.h"
#include "SpyFactory.h"
#include "Spy.h"


Soldier* SpyFactory::createSoldier()
{
    std::cout << "Creating Spy Object" << std::endl;
    return new Spy();
}
SpyFactory :: ~SpyFactory()
{
    std::cout << "Deleteing Spy Factory" << std::endl;
}
